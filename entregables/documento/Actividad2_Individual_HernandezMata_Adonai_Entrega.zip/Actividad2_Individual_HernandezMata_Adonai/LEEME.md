# Actividad 2 individual — Gestión del valor ganado (EVM)

**Adonai Samael Hernández Mata**
**Asignatura:** Metodología de Diseño y Gestión de Proyectos · Maestría en Inteligencia Artificial
**Profesora:** Adriana Cervantes Castillo

## Archivos

| Archivo | Qué es |
|---|---|
| `Actividad2_Individual_HernandezMata_Adonai.docx` | El documento de la actividad (4 páginas, Calibri 12, interlineado 1,5) |
| `Actividad2_Individual_HernandezMata_Adonai.pdf` | El mismo documento en PDF |

## Dónde está cada criterio de la rúbrica

| Criterio | En el documento | En el portal |
|---|---|---|
| 1. Parte A (mes 3) | Parte A: tabla de cálculo y preguntas 1–5 | https://evm.iagentek.com.mx/parte-a |
| 2. Parte B (mes 5) | Parte B: tabla comparativa, preguntas 1–5 y figura 1 | https://evm.iagentek.com.mx/parte-b |
| 3. Presentación | 4 páginas, Calibri 12, interlineado 1,5 | https://evm.iagentek.com.mx/cumplimiento |

Retroalimentación de la Actividad 1 (complementar lo ágil con lo clásico): la estrategia 3 de la Parte A5 y la
conclusión combinan el control clásico del valor ganado con iteraciones ágiles. En el portal: https://evm.iagentek.com.mx/hibrido

Resultados: mes 3 → CPI 0,734, SPI 0,788, EAC $130 450; mes 5 → CPI 0,929, SPI 0,989, EAC $122 000.

Portal interactivo con el cálculo paso a paso, la curva S, el enfoque híbrido, un laboratorio de escenarios y la simulación del cierre:
**https://evm.iagentek.com.mx** · código: https://github.com/azulls1/evm
